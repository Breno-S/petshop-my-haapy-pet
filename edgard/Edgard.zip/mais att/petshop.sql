-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 27-Abr-2023 às 17:08
-- Versão do servidor: 10.4.22-MariaDB
-- versão do PHP: 8.1.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `petshop`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `agendamento`
--

CREATE TABLE `agendamento` (
  `idAgendamento` int(10) NOT NULL,
  `id_cliente` int(10) DEFAULT NULL,
  `id_animal` int(10) DEFAULT NULL,
  `id_horario` int(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estrutura da tabela `cadastro_cliente`
--

CREATE TABLE `cadastro_cliente` (
  `idCadastro` int(10) NOT NULL,
  `id_cliente` int(10) DEFAULT NULL,
  `data_cad` datetime DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `celular` char(11) DEFAULT NULL,
  `senha` varchar(250) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `cadastro_cliente`
--

INSERT INTO `cadastro_cliente` (`idCadastro`, `id_cliente`, `data_cad`, `email`, `celular`, `senha`) VALUES
(1, 1, '2023-04-27 00:00:00', 'edgard@gmail.com', '11975647067', '202cb962ac59075b964b07152d234b70'),
(2, 2, '2023-04-27 00:00:00', 'nicole_brenda_assuncao@maiamaquinas.com.br', '11975647067', '81dc9bdb52d04dc20036dbd8313ed055'),
(3, 3, '2023-04-27 00:00:00', 'thiago_calebe_novaes@dbacomp.com.br', '73997901540', '81dc9bdb52d04dc20036dbd8313ed055'),
(4, 4, '2023-04-27 00:00:00', 'yago_damota@focoreducao.com.br', '31985927088', 'a0a080f42e6f13b3a2df133f073095dd'),
(5, 5, '2023-04-27 00:00:00', 'henrique_araujo@danielsalla.com.br', '21981870381', 'a0a080f42e6f13b3a2df133f073095dd'),
(6, 6, '2023-04-27 00:00:00', 'andreia-ribeiro73@mtc.eng.br', '79987583551', '43cca4b3de2097b9558efefd0ecc3588'),
(7, 7, '2023-04-27 00:00:00', 'flavia_bernardes@i9tec.com.br', '68987017968', '81dc9bdb52d04dc20036dbd8313ed055'),
(8, 8, '2023-04-27 00:00:00', 'vanessa-pires76@grupoitaipu.com.br', '63991138592', '81dc9bdb52d04dc20036dbd8313ed055'),
(9, 9, '2023-04-27 00:00:00', 'edgard@gmail.com', '73997901540', '202cb962ac59075b964b07152d234b70');

-- --------------------------------------------------------

--
-- Estrutura da tabela `cadastro_pet`
--

CREATE TABLE `cadastro_pet` (
  `idPet` int(10) NOT NULL,
  `id_cliente` int(10) DEFAULT NULL,
  `nome_pet` varchar(50) DEFAULT NULL,
  `raca` varchar(20) DEFAULT NULL,
  `cor_pet` varchar(20) DEFAULT NULL,
  `data_nasc_pet` date DEFAULT NULL,
  `peso_pet` float(2,2) DEFAULT NULL,
  `data_cad_pet` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estrutura da tabela `cartao`
--

CREATE TABLE `cartao` (
  `idCartao` int(10) NOT NULL,
  `id_cliente` int(10) DEFAULT NULL,
  `nome_cartao` varchar(100) DEFAULT NULL,
  `numero_cartao` int(12) DEFAULT NULL,
  `data_validade` date DEFAULT NULL,
  `bandeira` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estrutura da tabela `cliente`
--

CREATE TABLE `cliente` (
  `idCliente` int(10) NOT NULL,
  `id_endereco` int(10) DEFAULT NULL,
  `nome` varchar(100) DEFAULT NULL,
  `sobrenome` varchar(100) DEFAULT NULL,
  `cpf` char(11) DEFAULT NULL,
  `rg` char(9) DEFAULT NULL,
  `data_nasc` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `cliente`
--

INSERT INTO `cliente` (`idCliente`, `id_endereco`, `nome`, `sobrenome`, `cpf`, `rg`, `data_nasc`) VALUES
(1, 1, 'edgard', 'anjos', '37785312800', '398077678', '2005-06-20'),
(2, 2, 'edgard', 'anjos', '56746449939', '387014032', '1972-01-02'),
(3, 3, 'Thiago', 'Calebe Ryan Novaes', '93161491777', '101416465', '0000-00-00'),
(4, 4, 'Yago', 'Filipe da Mota', '99403099534', '299405527', '2005-06-20'),
(5, 5, 'Henrique', 'João Caio Araújo', '98974927802', '101250770', '2001-07-20'),
(6, 6, 'Andreia', 'Gabriela Ribeiro', '53636624342', '252778716', '2001-08-19'),
(7, 7, 'Flávia', 'Fátima Giovana Bernardes', '42936538998', '102837569', '2001-08-20'),
(8, 8, 'Vanessa', 'Regina Pires', '90062773208', '368697721', '2200-06-20'),
(9, 9, 'allef', '', '44876668809', '38227717X', '2000-07-20');

-- --------------------------------------------------------

--
-- Estrutura da tabela `endereco`
--

CREATE TABLE `endereco` (
  `idEndereco` int(10) NOT NULL,
  `estado` char(2) DEFAULT NULL,
  `municipio` varchar(30) DEFAULT NULL,
  `bairro` varchar(30) DEFAULT NULL,
  `logradouro` varchar(100) DEFAULT NULL,
  `numero` int(5) DEFAULT NULL,
  `cep` char(8) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `endereco`
--

INSERT INTO `endereco` (`idEndereco`, `estado`, `municipio`, `bairro`, `logradouro`, `numero`, `cep`) VALUES
(1, 'SP', 'São Paulo', 'Jardim dos Álamos', 'Rua José Vila Busquets', 175, '04883090'),
(2, 'BA', 'Salvador', 'Cidade Nova', '4ª Travessa 24 de Junho', 245, '40313355'),
(3, 'BA', 'Itabuna', 'Santa Inês', '3ª Travessa de Mutuns', 445, '45603788'),
(4, 'BA', 'Itabuna', 'Santa Inês', '3ª Travessa de Mutuns', 142, '45603788'),
(5, 'BA', 'Itabuna', 'Santa Inês', '3ª Travessa de Mutuns', 452, '45603788'),
(6, '', '', '', '', 134, '45603788'),
(7, 'AC', 'Rio Branco', 'Amapá', 'Rua Praia do Iaco', 41, '69906622'),
(8, 'TO', 'Palmas', 'Plano Diretor Norte', 'Quadra ACSU NE 60 Avenida LO 14', 167, '77006554'),
(9, 'BA', 'Itabuna', 'Santa Inês', '3ª Travessa de Mutuns', 167, '45603788');

-- --------------------------------------------------------

--
-- Estrutura da tabela `estoque`
--

CREATE TABLE `estoque` (
  `idEstoque` int(10) NOT NULL,
  `id_produto` int(10) DEFAULT NULL,
  `unidades` int(5) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estrutura da tabela `funcionarios`
--

CREATE TABLE `funcionarios` (
  `idFuncionario` int(10) NOT NULL,
  `cpf_funcionario` char(11) DEFAULT NULL,
  `nome_funcionario` varchar(100) DEFAULT NULL,
  `senha_funcionario` varchar(250) DEFAULT NULL,
  `cargo` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estrutura da tabela `horarios_disponiveis`
--

CREATE TABLE `horarios_disponiveis` (
  `idHorario` int(10) NOT NULL,
  `id_funcionario` int(10) DEFAULT NULL,
  `data` date DEFAULT NULL,
  `horario` time DEFAULT NULL,
  `reservado` tinyint(1) DEFAULT NULL,
  `servico` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estrutura da tabela `imagem_cliente`
--

CREATE TABLE `imagem_cliente` (
  `idImgCli` int(10) NOT NULL,
  `id_cadastro` int(10) DEFAULT NULL,
  `dir_img_cliente` varchar(250) DEFAULT NULL,
  `criado` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `imagem_cliente`
--

INSERT INTO `imagem_cliente` (`idImgCli`, `id_cadastro`, `dir_img_cliente`, `criado`) VALUES
(1, 8, '../images/imgCliente/644acee67a927.jpg', '2023-04-27 16:37:10'),
(2, 9, '../images/imgCliente/644ad265dc857.png', '2023-04-27 16:52:05');

-- --------------------------------------------------------

--
-- Estrutura da tabela `imagem_func`
--

CREATE TABLE `imagem_func` (
  `idImgFunc` int(10) NOT NULL,
  `id_funcionario` int(10) DEFAULT NULL,
  `dir_img_funcionario` varchar(250) DEFAULT NULL,
  `criado` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estrutura da tabela `imagem_pet`
--

CREATE TABLE `imagem_pet` (
  `idImgPet` int(10) NOT NULL,
  `id_pet` int(10) DEFAULT NULL,
  `dir_img_pet` varchar(250) DEFAULT NULL,
  `criado` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estrutura da tabela `imagem_produto`
--

CREATE TABLE `imagem_produto` (
  `idImgProd` int(10) NOT NULL,
  `id_produto` int(10) DEFAULT NULL,
  `dir_img_produto` varchar(250) DEFAULT NULL,
  `criado` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estrutura da tabela `itens_compra`
--

CREATE TABLE `itens_compra` (
  `idItem` int(10) NOT NULL,
  `id_pedido` int(10) DEFAULT NULL,
  `id_produto` int(10) DEFAULT NULL,
  `quantidade` int(5) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estrutura da tabela `pagamento`
--

CREATE TABLE `pagamento` (
  `idPagamento` int(10) NOT NULL,
  `id_pedido` int(10) DEFAULT NULL,
  `id_cartao` int(10) DEFAULT NULL,
  `data_pag` datetime DEFAULT NULL,
  `valor_pag` float(5,2) DEFAULT NULL,
  `tipo_pag` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estrutura da tabela `pedidos`
--

CREATE TABLE `pedidos` (
  `idPedido` int(10) NOT NULL,
  `id_cliente` int(10) DEFAULT NULL,
  `data_pedido` datetime DEFAULT NULL,
  `status_pedido` varchar(20) DEFAULT NULL,
  `valor_pedido` float(5,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estrutura da tabela `produtos`
--

CREATE TABLE `produtos` (
  `idProduto` int(10) NOT NULL,
  `nome_produto` varchar(100) DEFAULT NULL,
  `preco_produto` float(5,2) DEFAULT NULL,
  `marca_produto` varchar(20) DEFAULT NULL,
  `tipo_produto` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Índices para tabelas despejadas
--

--
-- Índices para tabela `agendamento`
--
ALTER TABLE `agendamento`
  ADD PRIMARY KEY (`idAgendamento`),
  ADD KEY `id_cliente` (`id_cliente`),
  ADD KEY `id_animal` (`id_animal`),
  ADD KEY `id_horario` (`id_horario`);

--
-- Índices para tabela `cadastro_cliente`
--
ALTER TABLE `cadastro_cliente`
  ADD PRIMARY KEY (`idCadastro`),
  ADD KEY `id_cliente` (`id_cliente`);

--
-- Índices para tabela `cadastro_pet`
--
ALTER TABLE `cadastro_pet`
  ADD PRIMARY KEY (`idPet`),
  ADD KEY `id_cliente` (`id_cliente`);

--
-- Índices para tabela `cartao`
--
ALTER TABLE `cartao`
  ADD PRIMARY KEY (`idCartao`),
  ADD KEY `id_cliente` (`id_cliente`);

--
-- Índices para tabela `cliente`
--
ALTER TABLE `cliente`
  ADD PRIMARY KEY (`idCliente`),
  ADD KEY `id_endereco` (`id_endereco`);

--
-- Índices para tabela `endereco`
--
ALTER TABLE `endereco`
  ADD PRIMARY KEY (`idEndereco`);

--
-- Índices para tabela `estoque`
--
ALTER TABLE `estoque`
  ADD PRIMARY KEY (`idEstoque`),
  ADD KEY `id_produto` (`id_produto`);

--
-- Índices para tabela `funcionarios`
--
ALTER TABLE `funcionarios`
  ADD PRIMARY KEY (`idFuncionario`);

--
-- Índices para tabela `horarios_disponiveis`
--
ALTER TABLE `horarios_disponiveis`
  ADD PRIMARY KEY (`idHorario`),
  ADD KEY `id_funcionario` (`id_funcionario`);

--
-- Índices para tabela `imagem_cliente`
--
ALTER TABLE `imagem_cliente`
  ADD PRIMARY KEY (`idImgCli`),
  ADD KEY `id_cadastro` (`id_cadastro`);

--
-- Índices para tabela `imagem_func`
--
ALTER TABLE `imagem_func`
  ADD PRIMARY KEY (`idImgFunc`),
  ADD KEY `id_funcionario` (`id_funcionario`);

--
-- Índices para tabela `imagem_pet`
--
ALTER TABLE `imagem_pet`
  ADD PRIMARY KEY (`idImgPet`),
  ADD KEY `id_pet` (`id_pet`);

--
-- Índices para tabela `imagem_produto`
--
ALTER TABLE `imagem_produto`
  ADD PRIMARY KEY (`idImgProd`),
  ADD KEY `id_produto` (`id_produto`);

--
-- Índices para tabela `itens_compra`
--
ALTER TABLE `itens_compra`
  ADD PRIMARY KEY (`idItem`),
  ADD KEY `id_pedido` (`id_pedido`),
  ADD KEY `id_produto` (`id_produto`);

--
-- Índices para tabela `pagamento`
--
ALTER TABLE `pagamento`
  ADD PRIMARY KEY (`idPagamento`),
  ADD KEY `id_pedido` (`id_pedido`),
  ADD KEY `id_cartao` (`id_cartao`);

--
-- Índices para tabela `pedidos`
--
ALTER TABLE `pedidos`
  ADD PRIMARY KEY (`idPedido`),
  ADD KEY `id_cliente` (`id_cliente`);

--
-- Índices para tabela `produtos`
--
ALTER TABLE `produtos`
  ADD PRIMARY KEY (`idProduto`);

--
-- AUTO_INCREMENT de tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `agendamento`
--
ALTER TABLE `agendamento`
  MODIFY `idAgendamento` int(10) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `cadastro_cliente`
--
ALTER TABLE `cadastro_cliente`
  MODIFY `idCadastro` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT de tabela `cadastro_pet`
--
ALTER TABLE `cadastro_pet`
  MODIFY `idPet` int(10) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `cartao`
--
ALTER TABLE `cartao`
  MODIFY `idCartao` int(10) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `cliente`
--
ALTER TABLE `cliente`
  MODIFY `idCliente` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT de tabela `endereco`
--
ALTER TABLE `endereco`
  MODIFY `idEndereco` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT de tabela `estoque`
--
ALTER TABLE `estoque`
  MODIFY `idEstoque` int(10) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `funcionarios`
--
ALTER TABLE `funcionarios`
  MODIFY `idFuncionario` int(10) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `horarios_disponiveis`
--
ALTER TABLE `horarios_disponiveis`
  MODIFY `idHorario` int(10) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `imagem_cliente`
--
ALTER TABLE `imagem_cliente`
  MODIFY `idImgCli` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de tabela `imagem_func`
--
ALTER TABLE `imagem_func`
  MODIFY `idImgFunc` int(10) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `imagem_pet`
--
ALTER TABLE `imagem_pet`
  MODIFY `idImgPet` int(10) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `imagem_produto`
--
ALTER TABLE `imagem_produto`
  MODIFY `idImgProd` int(10) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `itens_compra`
--
ALTER TABLE `itens_compra`
  MODIFY `idItem` int(10) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `pagamento`
--
ALTER TABLE `pagamento`
  MODIFY `idPagamento` int(10) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `pedidos`
--
ALTER TABLE `pedidos`
  MODIFY `idPedido` int(10) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `produtos`
--
ALTER TABLE `produtos`
  MODIFY `idProduto` int(10) NOT NULL AUTO_INCREMENT;

--
-- Restrições para despejos de tabelas
--

--
-- Limitadores para a tabela `agendamento`
--
ALTER TABLE `agendamento`
  ADD CONSTRAINT `agendamento_ibfk_1` FOREIGN KEY (`id_cliente`) REFERENCES `cliente` (`idCliente`),
  ADD CONSTRAINT `agendamento_ibfk_2` FOREIGN KEY (`id_animal`) REFERENCES `cadastro_pet` (`idPet`),
  ADD CONSTRAINT `agendamento_ibfk_3` FOREIGN KEY (`id_horario`) REFERENCES `horarios_disponiveis` (`idHorario`);

--
-- Limitadores para a tabela `cadastro_cliente`
--
ALTER TABLE `cadastro_cliente`
  ADD CONSTRAINT `cadastro_cliente_ibfk_1` FOREIGN KEY (`id_cliente`) REFERENCES `cliente` (`idCliente`);

--
-- Limitadores para a tabela `cadastro_pet`
--
ALTER TABLE `cadastro_pet`
  ADD CONSTRAINT `cadastro_pet_ibfk_1` FOREIGN KEY (`id_cliente`) REFERENCES `cliente` (`idCliente`);

--
-- Limitadores para a tabela `cartao`
--
ALTER TABLE `cartao`
  ADD CONSTRAINT `cartao_ibfk_1` FOREIGN KEY (`id_cliente`) REFERENCES `cliente` (`idCliente`);

--
-- Limitadores para a tabela `cliente`
--
ALTER TABLE `cliente`
  ADD CONSTRAINT `cliente_ibfk_1` FOREIGN KEY (`id_endereco`) REFERENCES `endereco` (`idEndereco`);

--
-- Limitadores para a tabela `estoque`
--
ALTER TABLE `estoque`
  ADD CONSTRAINT `estoque_ibfk_1` FOREIGN KEY (`id_produto`) REFERENCES `produtos` (`idProduto`);

--
-- Limitadores para a tabela `horarios_disponiveis`
--
ALTER TABLE `horarios_disponiveis`
  ADD CONSTRAINT `horarios_disponiveis_ibfk_1` FOREIGN KEY (`id_funcionario`) REFERENCES `funcionarios` (`idFuncionario`);

--
-- Limitadores para a tabela `imagem_cliente`
--
ALTER TABLE `imagem_cliente`
  ADD CONSTRAINT `imagem_cliente_ibfk_1` FOREIGN KEY (`id_cadastro`) REFERENCES `cadastro_cliente` (`idCadastro`);

--
-- Limitadores para a tabela `imagem_func`
--
ALTER TABLE `imagem_func`
  ADD CONSTRAINT `imagem_func_ibfk_1` FOREIGN KEY (`id_funcionario`) REFERENCES `funcionarios` (`idFuncionario`);

--
-- Limitadores para a tabela `imagem_pet`
--
ALTER TABLE `imagem_pet`
  ADD CONSTRAINT `imagem_pet_ibfk_1` FOREIGN KEY (`id_pet`) REFERENCES `cadastro_pet` (`idPet`);

--
-- Limitadores para a tabela `imagem_produto`
--
ALTER TABLE `imagem_produto`
  ADD CONSTRAINT `imagem_produto_ibfk_1` FOREIGN KEY (`id_produto`) REFERENCES `produtos` (`idProduto`);

--
-- Limitadores para a tabela `itens_compra`
--
ALTER TABLE `itens_compra`
  ADD CONSTRAINT `itens_compra_ibfk_1` FOREIGN KEY (`id_pedido`) REFERENCES `pedidos` (`idPedido`),
  ADD CONSTRAINT `itens_compra_ibfk_2` FOREIGN KEY (`id_produto`) REFERENCES `produtos` (`idProduto`);

--
-- Limitadores para a tabela `pagamento`
--
ALTER TABLE `pagamento`
  ADD CONSTRAINT `pagamento_ibfk_1` FOREIGN KEY (`id_pedido`) REFERENCES `pedidos` (`idPedido`),
  ADD CONSTRAINT `pagamento_ibfk_2` FOREIGN KEY (`id_cartao`) REFERENCES `cartao` (`idCartao`);

--
-- Limitadores para a tabela `pedidos`
--
ALTER TABLE `pedidos`
  ADD CONSTRAINT `pedidos_ibfk_1` FOREIGN KEY (`id_cliente`) REFERENCES `cliente` (`idCliente`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
